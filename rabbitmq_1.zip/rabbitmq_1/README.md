# rabbitmq

https://github.com/docker-library/rabbitmq