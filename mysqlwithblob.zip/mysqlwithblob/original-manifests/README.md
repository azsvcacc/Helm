# original manifests

The simple way to deploy with **kubectl** cli

# Usage

Execute next commands
```sh
kubectl create -f original-manifests/namespace.yaml
kubectl create -f original-manifests/mysql
kubectl create -f original-manifests/wordpress
```